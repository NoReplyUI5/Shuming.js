export const PREFIX = ["+"];
export const BOT_TOKEN = "MTI5MTcxNTM1NzE4NjMyNjUyOQ.GhjmuY.eG4hB0PhcN6xrD1rRSijUiJr4eab5Xo50k3OTo";
export const OWNER_IDS = ["1053918356375351386","618463472165978132"];
export const BOT_GUILD_ID = "1142066314572218481";

export const MONGO_URI = "mongodb+srv://og:dev@ogdev.zo7sdhy.mongodb.net/?retryWrites=true&w=majority&appName=ogdev";

export const TIME_ZONE = "Asia/dhaka";

export const RADIO_CHANNEL = "1297483247478902834";
export const RADIO_URL = 'https://boxradio-edge-02.streamafrica.net/lofi';

export const ANTI_BOT_MSG = ["1142069631855636480","1294738719424778273"];
export const BOT_BYPASS = ["155149108183695360","235148962103951360","536991182035746816"];
export const MSG_DEL_TIME = "10";

export const BOT_ROLE_ID = ["1255551831996891354"];
export const USER_ROLE_ID = ["1255551160027189298"];

export const MC_STATS_ENABLED = true;
export const MC_STATS_CHANNEL_ID = "1152913478521208833";
export const MC_STATS_IP = "play.biltusmp.xyz";
export const MC_STATS_PORT = "25565";
export const MC_STATS_ICON = "";
export const MC_STATS_REFRESH = "11";