export const Button = {
    name: "previousPage",
    run: async (interaction) => {
        // This is handled by the interaction logic inside the checkwarn command
        // No need for further button-specific logic
    }
};