export const Modal = {
    name: "ExampleModal",
    run: (interaction) => {
        interaction.reply({
            content: "This modal is correctly functioning."
        });
    }
}; // Code for the ExampleModal ModalForm