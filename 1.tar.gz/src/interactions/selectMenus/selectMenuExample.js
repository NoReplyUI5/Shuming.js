export const Menu = {
    name: "SelectMenuExample",
    run: (interaction) => {
        interaction.reply({
            content: "Here is your cookie! :cookie:"
        });
    }
}; // Code for SelectMenuExample SelectMenu